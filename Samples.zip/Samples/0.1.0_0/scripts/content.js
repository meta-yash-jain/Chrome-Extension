// content.js
var port;
var portName = 'hciComm';
$(document).ready(function () {

    console.log('content.js: Document ready');

    console.log("sessionStorage.loggedIn = " + sessionStorage.loggedIn);
    if (typeof sessionStorage.loggedIn === 'undefined') {

        console.log('content.js: Open port to background.js')
        port = chrome.runtime.connect({
            name: portName
        });
        console.log('content.js: Add listener to port');
        port.onMessage.addListener(function (message, sender) {
            console.log();
            console.log('content.js: received message from background.js, calling login');
            login(message)

        });


    // todo - add code to check url 
    // check the session data to see if we have logged in yet
   
       
    } else {
        console.log('content.js: Already logged in do nothing');
    }


    //// first get Tab ID from background.js
    //chrome.runtime.sendMessage({ message: "tabID" }, function (responce) {
    //    console.log("TabID = " + responce.tabID);
    //    var tabID = responce.tabID;

    //    // see if we are on a login page
    //    //var inputs = getInputs();

    //    if (hasPassword(getInputs())) {
    //        // this page has a password input - login page?
    //        // see if this tab id has been logged into yet
    //        if (!loginTried(tabID)) {
    //            // login to page
    //            pupulateInputs(getInputs())
    //            //submitPage();
    //            // save tab.id to local storage
    //            saveToLocalStorage(hciKey, tabID);
    //            console.log("after saved");

    //            chrome.storage.local.get(hciKey, function (items) {
    //                console.log(items.hciLTID);
    //            });
               
                
    //        }

    //    }
    //});
    
});

function login(message) {
    console.log('login: start');
    if (hasPassword(getInputs())) {
        // this page has a password input - login page?



        // login to page
        pupulateInputs(getInputs(), message);
        //set loggedin value in sessionStorage
        sessionStorage.loggedIn = 'true';
        submitPage();
        // close HCINativeMessenger?
        sendStatus('sendClose');

    }
    console.log('login: exiting...');
}


function submitPage() {
    document.getElementsByTagName("form")[0].submit();
}

function pupulateInputs(userInputs, message) {
    var result = false;
    console.log('pupulateInputs: Start');
    for (var i = 0; i < userInputs.length; i++) {
        if (userInputs[i].type === "password") {
            // found password textbox
            if (userInputs[i-1].type == "text") {
                userInputs[i - 1].value = getUsername(message);
                userInputs[i].value = getPW(message);
                result = true;
            } else {
                // the username input was not the input before the password input - search the inputs to find the text input
                for (var j = 0; j < userInputs.length; j++) {
                    if (userInputs[j].type == "text") {
                        userInputs[j].value = getUsername(message);
                        userInputs[i].value = getPW(message);
                        result = true;
                    }
                }
            }
        }
    }
    console.log('pupulateInputs: result = ' + result);
    return result;
}

function getUsername(message) {
    var username;
    if (message.Username == "") {
        username = ""
        console.log('getUserName: message.Username = ""');
    }
    else {
        username = message.Username
    }
    
    return username;
}

function getPW(message){
    var password;
    if (message.Password == "") {
        password = ""
        console.log('getPW: message.Password = ""');
    }
    else {
        password = message.Password
    }
    return password;
}


function hasPassword(inputs) {
    // check the truthieness of inputs 
    if (inputs) {
        for (var i = 0; i < inputs.length; i++) {
            if (inputs[i].type === "password") {
                console.log("hasPassword: true");
                return true
            }
        }
    }
    console.log("hasPassword: false");
    return false;
}

function getInputs() {

    return document.getElementsByTagName("input");
}

function changeInputFieldColor(color, message){
//highlight username and password fields
    
    if ($("#" + message.UsernameID) !== null) {
        console.log('getUserInput: find password field');
        if ($("#" + message.PasswordID) !== null) {
            console.log('getUserInput: set background color for password');
            $("#" + message.PasswordID).css("background-color", color);
            console.log('getUserInput: set background color for  username');
            $("#" + message.UsernameID).css("background-color", color);
        } else {
            console.log('getUserInput: password element ID: ' + message.PasswordID + ' not found.');
        }
    } else {
        console.log('getUserInput: username element ID: ' + message.UsernameID + ' not found.');
    }

}

function sendStatus(statusMessage) {
    console.log('sendStatus: Start');

    port.postMessage({
        status: statusMessage
    });
    console.log('sendStatus: exiting...');
}

function sendMessage(statusMessage) {
    console.log('sendMessage: Start');

    port.postMessage(statusMessage);
    console.log('sendMessage: exiting...');
}