console.log("background.js here!")
//var connected = false;
var contentPort;
var nativePort;

chrome.runtime.onConnect.addListener(function (port) {
    if (port.name == 'hciComm') {

        console.log('Connected to hciComm');
        contentPort = port;
        // activate the icon
        chrome.pageAction.show(contentPort.sender.tab.id);
        console.log('Call nativeHost');
        nativeHost()
        console.log('After call to nativeHost');
        console.log('Call sendMessageToNativeHost');
        sendMessageToNativeHost({ url: contentPort.sender.tab.url, id: chrome.runtime.getManifest().name.toLowerCase() });
        console.log('After call to sendMessageToNativeHost');

        contentPort.onMessage.addListener(function (msg) {
            console.log('contentPort Listener:' + JSON.stringify(msg))
            if (msg.status !== undefined) {
                sendMessageToNativeHost(msg);
            }
        });
    } else {
        console.log("port.name = " + port.name);
	    port.onMessage.addListener(function (msg) {
            console.log('port Listener:' + JSON.stringify(msg))
            if (msg.command !== undefined) {
                console.log("Received command " + msg.command);
	    	    if (msg.command.indexOf('closeTab') != -1) {
		            closeTab(port)
	    	    }
            }
        });
    }

});

function checkURL(url) {
    // get urls from localStorage
    var urlList = JSON.parse(localStorage['hciURLList']);
    if (urlList) {
        for (var i = 0; i < length; i++) {

        }
    } else {
        console.log('checkURL: ');
    }
    
}


function closeTab(port) {
    console.log("closeTab: Start.");
    chrome.tabs.query({windowType:'normal'}, function(tabs) {
        console.log('Number of open tabs in all normal browser windows:',tabs.length);
	if (tabs.length < 2) {
	    // our tab is the only tab - open a new tab so the browser does not close
	    chrome.tabs.create({}, function(tab) {
    	    });
	}
	chrome.tabs.remove(port.sender.tab.id);

    	console.log("closeTab: disconnect port.");
    	port.disconnect();

	console.log("closeTab: exiting....");

    }); 
}

function nativeHost() {
    console.log('nativeHost: Start');
    console.log('nativeHost: Get manifest');
    var manifest = chrome.runtime.getManifest();
    console.log('nativeHost: manifest.nativehost_name.toLowerCase = ' + manifest.nativehost_name.toLowerCase());
    
    nativePort = chrome.runtime.connectNative(manifest.nativehost_name.toLowerCase());
    nativePort.onMessage.addListener(function (msg) {
        console.log("nativeHost: Received msg from nativePort");
        //console.log('nativeHost: msg = ' + JSON.stringify(msg))
        if (msg.status === undefined) {
            try {
                contentPort.postMessage(msg);
            }
            catch (err) {
                // contentPort is null this happens if the content script reloads before the login is complete
                // causing us to launch a nativeMessagingHost again.  
                console.log('Error connecting to contentPort. Send close to NativeMessagingHost Err = ' + err)
                sendMessageToNativeHost({ status: 'sendClose' });
            }
        }
        return true; //return true to keep port alive
    });
    nativePort.onDisconnect.addListener(function () {
        console.log("nativeHost: Disconnected");
        chrome.pageAction.hide(contentPort.sender.tab.id);
    });

    console.log('nativeHost: exiting...');
}

function sendMessageToNativeHost(message) {
    console.log('sendMessageToNativeHost: Start');
    nativePort.postMessage(message);
    console.log('sendMessageToNativeHost: exiting...');
}

function callContent(msg) {
    console.log('Calling content script!')

    chrome.tabs.query({
        active: true,
        currentWindow: true
    }, function (tabs) {
        chrome.tabs.sendMessage(tabs[0].id, msg, function (response) { });
        console.log('Message sent to content script');
    });
}
